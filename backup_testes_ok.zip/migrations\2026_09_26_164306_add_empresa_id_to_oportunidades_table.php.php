<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('oportunidades', function (Blueprint $table) {
            $table->foreignId('empresa_id')
                  ->nullable()
                  ->after('created_by')
                  ->constrained('empresas')
                  ->onDelete('set null');
        });
    }

    public function down(): void
    {
        Schema::table('oportunidades', function (Blueprint $table) {
            $table->dropForeign(['empresa_id']);
            $table->dropColumn('empresa_id');
        });
    }
};